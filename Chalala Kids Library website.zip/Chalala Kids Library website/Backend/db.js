const mysql = require("mysql2");

const db = mysql.createConnection({
  host: "localhost",
  user: "root",   // change if needed
  password: "",   // your MySQL password
  database: "kids_library"
});

db.connect(err => {
  if (err) throw err;
  console.log("✅ MySQL Connected...");
});

module.exports = db;