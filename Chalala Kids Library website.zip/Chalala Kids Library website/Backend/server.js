const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Import routes
const booksRoute = require("./routes/books");
const eventsRoute = require("./routes/events");
const contactRoute = require("./routes/contact");

app.use("/api/books", booksRoute);
app.use("/api/events", eventsRoute);
app.use("/api/contact", contactRoute);

const PORT = 5000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));