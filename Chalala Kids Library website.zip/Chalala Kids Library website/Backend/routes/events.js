const express = require("express");
const router = express.Router();
const db = require("../db");

// Get all events
router.get("/", (req, res) => {
  db.query("SELECT * FROM events", (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// Add new event
router.post("/", (req, res) => {
  const { name, date } = req.body;
  db.query("INSERT INTO events (name, date) VALUES (?, ?)", [name, date], (err, result) => {
    if (err) throw err;
    res.json({ message: "🎉 Event added successfully!" });
  });
});

module.exports = router;