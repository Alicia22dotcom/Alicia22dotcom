const express = require("express");
const router = express.Router();
const db = require("../db");

// Get all books
router.get("/", (req, res) => {
  db.query("SELECT * FROM books", (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// Add new book
router.post("/", (req, res) => {
  const { title, author } = req.body;
  db.query("INSERT INTO books (title, author) VALUES (?, ?)", [title, author], (err, result) => {
    if (err) throw err;
    res.json({ message: "📚 Book added successfully!" });
  });
});

module.exports = router;