const express = require("express");
const router = express.Router();
const db = require("../db");

// Save contact message
router.post("/", (req, res) => {
  const { name, email, message } = req.body;
  db.query("INSERT INTO contact (name, email, message) VALUES (?, ?, ?)", [name, email, message], (err, result) => {
    if (err) throw err;
    res.json({ message: "✅ Message received! We’ll get back soon." });
  });
});

module.exports = router;